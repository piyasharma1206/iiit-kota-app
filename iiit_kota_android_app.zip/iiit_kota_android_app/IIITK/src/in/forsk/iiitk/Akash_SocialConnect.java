package in.forsk.iiitk;

import android.app.Activity;
import android.os.Bundle;

public class Akash_SocialConnect extends Activity{
	
	@Override
	protected void onCreate(Bundle bundle) {
	
		super.onCreate(bundle); // comment for conflict
	}

}
